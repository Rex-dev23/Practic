<?php
class ModelExtensionModuleProscroller extends Model {
	
}
?>