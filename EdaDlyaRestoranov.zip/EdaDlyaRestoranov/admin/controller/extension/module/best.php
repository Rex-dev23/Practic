<?php
class ControllerExtensionModuleBest extends Controller {
	private $error = array(); 
	
	public function index() {   
		$this->language->load('extension/module/best');

		$this->document->setTitle($this->language->get('heading_title_title'));
		
		$this->load->model('extension/module');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			if (!isset($this->request->get['module_id'])) {
				$this->model_extension_module->addModule('best', $this->request->post);
			} else {
				$this->model_extension_module->editModule($this->request->get['module_id'], $this->request->post);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true));
		}
				
		$data['heading_title'] = $this->language->get('heading_title');
		$data['heading_title_title'] = $this->language->get('heading_title_title');

		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_content_top'] = $this->language->get('text_content_top');
		$data['text_content_bottom'] = $this->language->get('text_content_bottom');		
		$data['text_column_left'] = $this->language->get('text_column_left');
		$data['text_column_right'] = $this->language->get('text_column_right');
		
		$data['entry_product_day'] = $this->language->get('entry_product_day');
		$data['entry_product_uspey'] = $this->language->get('entry_product_uspey');
		$data['entry_product'] = $this->language->get('entry_product');
		$data['entry_products'] = $this->language->get('entry_products');
		$data['entry_limit'] = $this->language->get('entry_limit');
		$data['entry_image'] = $this->language->get('entry_image');
		$data['entry_layout'] = $this->language->get('entry_layout');
		$data['entry_position'] = $this->language->get('entry_position');
		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_sort_order'] = $this->language->get('entry_sort_order');
		
		$data['entry_addit_image'] = $this->language->get('entry_addit_image');
		$data['rating_and_prodano'] = $this->language->get('rating_and_prodano');
		$data['text_responsive_setting'] = $this->language->get('text_responsive_setting');
		$data['text_responsive'] = $this->language->get('text_responsive');
		$data['text_kolvo_responsive_setting'] = $this->language->get('text_kolvo_responsive_setting');
		$data['on'] = $this->language->get('on');
		$data['off'] = $this->language->get('off');
		
		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');
		$data['button_add_module'] = $this->language->get('button_add_module');
		$data['button_remove'] = $this->language->get('button_remove');
		
		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['entry_name'] = $this->language->get('entry_name');
		$data['entry_product'] = $this->language->get('entry_product');
		$data['entry_limit'] = $this->language->get('entry_limit');
		$data['entry_width'] = $this->language->get('entry_width');
		$data['entry_height'] = $this->language->get('entry_height');
		$data['entry_status'] = $this->language->get('entry_status');
		$data['ostalos'] = $this->language->get('ostalos');
		
		$data['style_best'] = $this->language->get('style_best');
		$data['color_best_day'] = $this->language->get('color_best_day');
		$data['header_color_best_day'] = $this->language->get('header_color_best_day');
		$data['header_color_best_uspey'] = $this->language->get('header_color_best_uspey');
		$data['setting_day'] = $this->language->get('setting_day');
		$data['setting_uspey'] = $this->language->get('setting_uspey');
		$data['text_off_product_day'] = $this->language->get('text_off_product_day');
		$data['text_off_addit'] = $this->language->get('text_off_addit');
		$data['off_addit_pokaz'] = $this->language->get('off_addit_pokaz');
		$data['text_rating_and_prodano'] = $this->language->get('text_rating_and_prodano');
		$data['text_schetchik'] = $this->language->get('text_schetchik');
		$data['style_best'] = $this->language->get('style_best');
		$data['text_color_best_day'] = $this->language->get('text_color_best_day');
		$data['text_header_color_best_day'] = $this->language->get('text_header_color_best_day');
		$data['text_header_color_best_uspey'] = $this->language->get('text_header_color_best_uspey');
		
		$data['text_color_name_product'] = $this->language->get('text_color_name_product');
		$data['text_font_size_name_product'] = $this->language->get('text_font_size_name_product');
		$data['text_color_price_product'] = $this->language->get('text_color_price_product');
		$data['text_font_size_price_product'] = $this->language->get('text_font_size_price_product');
		$data['text_color_priceold_product'] = $this->language->get('text_color_priceold_product');
		$data['text_font_size_priceold_product'] = $this->language->get('text_font_size_priceold_product');
		$data['text_color_pricenew_product'] = $this->language->get('text_color_pricenew_product');
		$data['text_font_size_pricenew_product'] = $this->language->get('text_font_size_pricenew_product');
		$data['text_gradient_ostatka'] = $this->language->get('text_gradient_ostatka');
		$data['text_ot'] = $this->language->get('text_ot');
		$data['text_do'] = $this->language->get('text_do');
		$data['text_gradient_schetchik'] = $this->language->get('text_gradient_schetchik');
		$data['text_color_bg_button_cart'] = $this->language->get('text_color_bg_button_cart');
		$data['text_color_text_button_cart'] = $this->language->get('text_color_text_button_cart');
		$data['text_font_size_text_button_cart'] = $this->language->get('text_font_size_text_button_cart');
		$data['text_color_compare'] = $this->language->get('text_color_compare');
		$data['text_color_wishlist'] = $this->language->get('text_color_wishlist');
		
		$data['protection'] = $this->language->get('protection');
		$data['help_protection'] = $this->language->get('help_protection');
		$data['help_cod_protection'] = $this->language->get('help_cod_protection');
		$data['protection_no_base'] = $this->language->get('protection_no_base');
		
 		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = '';
		}

		if (isset($this->error['width'])) {
			$data['error_width'] = $this->error['width'];
		} else {
			$data['error_width'] = '';
		}

		if (isset($this->error['height'])) {
			$data['error_height'] = $this->error['height'];
		} else {
			$data['error_height'] = '';
		}
				
  		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true)
		);

		if (!isset($this->request->get['module_id'])) {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('extension/module/best', 'token=' . $this->session->data['token'], true)
			);
		} else {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('extension/module/best', 'token=' . $this->session->data['token'] . '&module_id=' . $this->request->get['module_id'], true)
			);
		}
		
		if (!isset($this->request->get['module_id'])) {
			$data['action'] = $this->url->link('extension/module/best', 'token=' . $this->session->data['token'], 'SSL');
		} else {
			$data['action'] = $this->url->link('extension/module/best', 'token=' . $this->session->data['token'] . '&module_id=' . $this->request->get['module_id'], 'SSL');
		}

		$data['cancel'] = $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL');

		if (isset($this->request->get['module_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$module_info = $this->model_extension_module->getModule($this->request->get['module_id']);
		}

		$data['token'] = $this->session->data['token'];
		
		if (isset($this->request->post['protection_cod'])) {
			$data['protection_cod'] = $this->request->post['protection_cod'];
		} elseif (!empty($module_info)) {
			$data['protection_cod'] = $module_info['protection_cod'];
		} else {
			$data['protection_cod'] = false;
		}
		
		if (isset($this->request->post['product_day'])) {
			$data['product_day'] = $this->request->post['product_day'];
		} elseif (!empty($module_info)) {
			$data['product_day'] = $module_info['product_day'];
		} else {
			$data['product_day'] = false;
		}
		
		if (isset($this->request->post['product_uspey'])) {
			$data['product_uspey'] = $this->request->post['product_uspey'];
		} elseif (!empty($module_info)) {
			$data['product_uspey'] = $module_info['product_uspey'];
		} else {
			$data['product_uspey'] = false;
		}
		
		$this->load->model('catalog/product');

		if (isset($this->request->post['product_day'])) {
			$products_day = $this->request->post['product_day'];
		} elseif (!empty($module_info)) {
			$products_day = $module_info['product_day'];
		} else {
			$products_day = array();
		}
		
		$data['products_day'] = array();
		
		foreach ($products_day as $product_id) {
			$product_info = $this->model_catalog_product->getProduct($product_id);
			
			if ($product_info) {
				$data['products_day'][] = array(
					'product_id' => $product_info['product_id'],
					'name'       => $product_info['name']
				);
			}
		}

		if (isset($this->request->post['product_uspey'])) {
			$products_uspey = $this->request->post['product_uspey'];
		} elseif (!empty($module_info)) {
			$products_uspey = $module_info['product_uspey'];
		} else {
			$products_uspey = array();
		}

		$data['products_uspey'] = array();
		
		if (!empty($products_uspey)) {
			foreach ($products_uspey as $product_id) {
				$product_info = $this->model_catalog_product->getProduct($product_id);
				
				if ($product_info) {
					$data['products_uspey'][] = array(
						'product_id' => $product_info['product_id'],
						'name'       => $product_info['name']
					);
				}
			}
		}
		
		if (isset($this->request->post['name'])) {
			$data['name'] = $this->request->post['name'];
		} elseif (!empty($module_info)) {
			$data['name'] = $module_info['name'];
		} else {
			$data['name'] = '';
		}
		
		if (isset($this->request->post['pervon_kol_vo'])) {
			$data['pervon_kol_vo'] = $this->request->post['pervon_kol_vo'];
		} elseif (!empty($module_info)) {
			$data['pervon_kol_vo'] = $module_info['pervon_kol_vo'];
		} else {
			$data['pervon_kol_vo'] = 2000;
		}
		
		if (isset($this->request->post['off_product_day'])) {
			$data['off_product_day'] = $this->request->post['off_product_day'];
		} elseif (!empty($module_info)) {
			$data['off_product_day'] = $module_info['off_product_day'];
		} else {
			$data['off_product_day'] = 1;
		}
		
		if (isset($this->request->post['rating_and_prodano'])) {
			$data['rating_and_prodano'] = $this->request->post['rating_and_prodano'];
		} elseif (!empty($module_info)) {
			$data['rating_and_prodano'] = $module_info['rating_and_prodano'];
		} else {
			$data['rating_and_prodano'] = 1;
		}
		
		if (isset($this->request->post['off_addit'])) {
			$data['off_addit'] = $this->request->post['off_addit'];
		} elseif (!empty($module_info)) {
			$data['off_addit'] = $module_info['off_addit'];
		} else {
			$data['off_addit'] = 1;
		}
		
		if (isset($this->request->post['image_addit_width'])) {
			$data['image_addit_width'] = $this->request->post['image_addit_width'];
		} elseif (!empty($module_info)) {
			$data['image_addit_width'] = $module_info['image_addit_width'];
		} else {
			$data['image_addit_width'] = 25;
		}
		
		if (isset($this->request->post['image_addit_height'])) {
			$data['image_addit_height'] = $this->request->post['image_addit_height'];
		} elseif (!empty($module_info)) {
			$data['image_addit_height'] = $module_info['image_addit_height'];
		} else {
			$data['image_addit_height'] = 25;
		}
		
		if (isset($this->request->post['color_best_day'])) {
			$data['color_best_day'] = $this->request->post['color_best_day'];
		} elseif (!empty($module_info)) {
			$data['color_best_day'] = $module_info['color_best_day'];
		} else {
			$data['color_best_day'] = "#2E85BC";
		}
			
		if (isset($this->request->post['header_color_best_day'])) {
			$data['header_color_best_day'] = $this->request->post['header_color_best_day'];
		} elseif (!empty($module_info)) {
			$data['header_color_best_day'] = $module_info['header_color_best_day'];
		} else {
			$data['header_color_best_day'] = "#FFFFFF";
		}
		
		if (isset($this->request->post['header_color_best_uspey'])) {
			$data['header_color_best_uspey'] = $this->request->post['header_color_best_uspey'];
		} elseif (!empty($module_info)) {
			$data['header_color_best_uspey'] = $module_info['header_color_best_uspey'];
		} else {
			$data['header_color_best_uspey'] = "#333333";
		}
		
		if (isset($this->request->post['color_name_product'])) {
			$data['color_name_product'] = $this->request->post['color_name_product'];
		} elseif (!empty($module_info)) {
			$data['color_name_product'] = $module_info['color_name_product'];
		} else {
			$data['color_name_product'] = "#2b2c2d";
		}
		
		if (isset($this->request->post['font_size_name_product'])) {
			$data['font_size_name_product'] = $this->request->post['font_size_name_product'];
		} elseif (!empty($module_info)) {
			$data['font_size_name_product'] = $module_info['font_size_name_product'];
		} else {
			$data['font_size_name_product'] = "16";
		}
		
		if (isset($this->request->post['color_price_product'])) {
			$data['color_price_product'] = $this->request->post['color_price_product'];
		} elseif (!empty($module_info)) {
			$data['color_price_product'] = $module_info['color_price_product'];
		} else {
			$data['color_price_product'] = "#ed297b";
		}
		
		if (isset($this->request->post['font_size_price_product'])) {
			$data['font_size_price_product'] = $this->request->post['font_size_price_product'];
		} elseif (!empty($module_info)) {
			$data['font_size_price_product'] = $module_info['font_size_price_product'];
		} else {
			$data['font_size_price_product'] = "18";
		}
		
		if (isset($this->request->post['color_priceold_product'])) {
			$data['color_priceold_product'] = $this->request->post['color_priceold_product'];
		} elseif (!empty($module_info)) {
			$data['color_priceold_product'] = $module_info['color_priceold_product'];
		} else {
			$data['color_priceold_product'] = "#777777";
		}
		
		if (isset($this->request->post['font_size_priceold_product'])) {
			$data['font_size_priceold_product'] = $this->request->post['font_size_priceold_product'];
		} elseif (!empty($module_info)) {
			$data['font_size_priceold_product'] = $module_info['font_size_priceold_product'];
		} else {
			$data['font_size_priceold_product'] = "12";
		}
		
		if (isset($this->request->post['color_pricenew_product'])) {
			$data['color_pricenew_product'] = $this->request->post['color_pricenew_product'];
		} elseif (!empty($module_info)) {
			$data['color_pricenew_product'] = $module_info['color_pricenew_product'];
		} else {
			$data['color_pricenew_product'] = "#ed297b";
		}
		
		if (isset($this->request->post['font_size_pricenew_product'])) {
			$data['font_size_pricenew_product'] = $this->request->post['font_size_pricenew_product'];
		} elseif (!empty($module_info)) {
			$data['font_size_pricenew_product'] = $module_info['font_size_pricenew_product'];
		} else {
			$data['font_size_pricenew_product'] = "18";
		}
		
		if (isset($this->request->post['ot_gradient_ostatka'])) {
			$data['ot_gradient_ostatka'] = $this->request->post['ot_gradient_ostatka'];
		} elseif (!empty($module_info)) {
			$data['ot_gradient_ostatka'] = $module_info['ot_gradient_ostatka'];
		} else {
			$data['ot_gradient_ostatka'] = "#ffffff";
		}
		
		if (isset($this->request->post['do_gradient_ostatka'])) {
			$data['do_gradient_ostatka'] = $this->request->post['do_gradient_ostatka'];
		} elseif (!empty($module_info)) {
			$data['do_gradient_ostatka'] = $module_info['do_gradient_ostatka'];
		} else {
			$data['do_gradient_ostatka'] = "#555555";
		}
		
		if (isset($this->request->post['ot_gradient_schetchik'])) {
			$data['ot_gradient_schetchik'] = $this->request->post['ot_gradient_schetchik'];
		} elseif (!empty($module_info)) {
			$data['ot_gradient_schetchik'] = $module_info['ot_gradient_schetchik'];
		} else {
			$data['ot_gradient_schetchik'] = "#3a3a3a";
		}
		
		if (isset($this->request->post['do_gradient_schetchik'])) {
			$data['do_gradient_schetchik'] = $this->request->post['do_gradient_schetchik'];
		} elseif (!empty($module_info)) {
			$data['do_gradient_schetchik'] = $module_info['do_gradient_schetchik'];
		} else {
			$data['do_gradient_schetchik'] = "#797979";
		}
		
		if (isset($this->request->post['color_bg_button_cart'])) {
			$data['color_bg_button_cart'] = $this->request->post['color_bg_button_cart'];
		} elseif (!empty($module_info)) {
			$data['color_bg_button_cart'] = $module_info['color_bg_button_cart'];
		} else {
			$data['color_bg_button_cart'] = "#333333";
		}
		
		if (isset($this->request->post['color_text_button_cart'])) {
			$data['color_text_button_cart'] = $this->request->post['color_text_button_cart'];
		} elseif (!empty($module_info)) {
			$data['color_text_button_cart'] = $module_info['color_text_button_cart'];
		} else {
			$data['color_text_button_cart'] = "#ffffff";
		}
		
		if (isset($this->request->post['font_size_text_button_cart'])) {
			$data['font_size_text_button_cart'] = $this->request->post['font_size_text_button_cart'];
		} elseif (!empty($module_info)) {
			$data['font_size_text_button_cart'] = $module_info['font_size_text_button_cart'];
		} else {
			$data['font_size_text_button_cart'] = "12";
		}
		
		if (isset($this->request->post['color_compare'])) {
			$data['color_compare'] = $this->request->post['color_compare'];
		} elseif (!empty($module_info)) {
			$data['color_compare'] = $module_info['color_compare'];
		} else {
			$data['color_compare'] = "#000000";
		}
		
		if (isset($this->request->post['color_wishlist'])) {
			$data['color_wishlist'] = $this->request->post['color_wishlist'];
		} elseif (!empty($module_info)) {
			$data['color_wishlist'] = $module_info['color_wishlist'];
		} else {
			$data['color_wishlist'] = "#000000";
		}
		
		
		
		if (isset($this->request->post['schetchik'])) {
			$data['schetchik'] = $this->request->post['schetchik'];
		} elseif (!empty($module_info)) {
			$data['schetchik'] = $module_info['schetchik'];
		} else {
			$data['schetchik'] = 1;
		}
		
		if (isset($this->request->post['responsive_setting'])) {
			$data['responsive_setting'] = $this->request->post['responsive_setting'];
		} elseif (!empty($module_info)) {
			$data['responsive_setting'] = $module_info['responsive_setting'];
		} else {
			$data['responsive_setting'] = 1;
		}
		
		if (isset($this->request->post['kol_vo_responsive_setting'])) {
			$data['kol_vo_responsive_setting'] = $this->request->post['kol_vo_responsive_setting'];
		} elseif (!empty($module_info)) {
			$data['kol_vo_responsive_setting'] = $module_info['kol_vo_responsive_setting'];
		} else {
			$data['kol_vo_responsive_setting'] = 3;
		}
			
			
		if (isset($this->request->post['limit'])) {
			$data['limit'] = $this->request->post['limit'];
		} elseif (!empty($module_info)) {
			$data['limit'] = $module_info['limit'];
		} else {
			$data['limit'] = 5;
		}

		if (isset($this->request->post['width'])) {
			$data['width'] = $this->request->post['width'];
		} elseif (!empty($module_info)) {
			$data['width'] = $module_info['width'];
		} else {
			$data['width'] = 150;
		}

		if (isset($this->request->post['height'])) {
			$data['height'] = $this->request->post['height'];
		} elseif (!empty($module_info)) {
			$data['height'] = $module_info['height'];
		} else {
			$data['height'] = 150;
		}

		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($module_info)) {
			$data['status'] = $module_info['status'];
		} else {
			$data['status'] = '';
		}
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/module/best', $data));
	}
	
	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/module/best')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if ((utf8_strlen($this->request->post['name']) < 3) || (utf8_strlen($this->request->post['name']) > 64)) {
			$this->error['name'] = $this->language->get('error_name');
		}

		if (!$this->request->post['width']) {
			$this->error['width'] = $this->language->get('error_width');
		}

		if (!$this->request->post['height']) {
			$this->error['height'] = $this->language->get('error_height');
		}

		return !$this->error;
	}
}
?>