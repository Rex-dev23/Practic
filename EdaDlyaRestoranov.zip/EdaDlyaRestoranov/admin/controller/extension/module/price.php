<?php
if ( version_compare(VERSION, '2.2.0.0', '>=') ) { 
	class ControllerExtensionModulePrice extends ControllerPrice {
		public function __construct ($registry) {
			parent::__construct($registry);
			parent::setVersion('2.3.1');
			$entity['path']               = 'extension/module/price';
			$entity['modules_path']       = 'extension/extension&module=type';
			$entity['themeLimit']         = $this->config->get($this->config->get('config_theme') . '_product_limit');
			$entity['imageWidth']         = $this->config->get($this->config->get('config_theme') . '_image_cart_width');
			$entity['imageHeight']        = $this->config->get($this->config->get('config_theme') . '_image_cart_height');
			$entity['descriptionLength']  = $this->config->get($this->config->get('config_theme') . '_product_description_length');
			parent::setVersionEntity($entity);
		}
	}
} else {
	class ControllerModulePrice extends ControllerPrice {
		public function __construct ($registry) {
			parent::__construct($registry);
			parent::setVersion('2.1.1');
			$entity['path']              = 'module/price';
			$entity['modules_path']      = 'extension/module';
			$entity['themeLimit']        = $this->config->get('config_product_limit');
			$entity['imageWidth']        = $this->config->get('config_image_cart_width');
			$entity['imageHeight']       = $this->config->get('config_image_cart_height');
			$entity['descriptionLength'] = $this->config->get('config_product_description_length');
			parent::setVersionEntity($entity);
		}
	}
}

class ControllerPrice extends Controller {
    private $error = array();

	protected function setVersion($ver){
		$this->version = $ver;
	}
	protected function setVersionEntity($entity = array()){
		$this->path              = $entity['path'];
		$this->modulesPath       = $entity['modules_path'];
		$this->themeLimit        = $entity['themeLimit'];
		$this->imageWidth        = $entity['imageWidth'];
		$this->imageHeight       = $entity['imageHeight'];
		$this->descriptionLength = $entity['descriptionLength'];
	}

    public function index() {
        $this->language->load($this->path);

        $this->document->setTitle(strip_tags($this->language->get('heading_title')));

        $this->load->model('setting/setting');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {

			$this->model_setting_setting->editSetting('price_list', $this->request->post);
			if (!empty($this->request->post['seo_url'])) {
				$sql = "DELETE FROM " . DB_PREFIX . "url_alias WHERE query = 'product/price'";
				$this->db->query($sql);
				$sql = "INSERT INTO " . DB_PREFIX . "url_alias SET query = 'product/price', keyword = '" . $this->db->escape($this->request->post['seo_url']) . "'";
				$this->db->query($sql);
			}
			$this->session->data['success'] = $this->language->get('text_success');

			if (isset($this->request->get['apply'])) {
				$this->response->redirect($this->url->link($this->path, 'token=' . $this->session->data['token'], true));
			}
			$this->response->redirect($this->url->link($this->modulesPath, 'token=' . $this->session->data['token'], true));
		}

		$this->load->model('localisation/language');
		$languages = $this->model_localisation_language->getLanguages();
		foreach ($languages as $key=>$language) {
			$data['languages'][$key] = $language;
			if ( version_compare(VERSION, '2.2.0.0', '>') ) { 
				$data['languages'][$key]['image'] = 'language/' . $language['code'] . '/' . $language['code'] . '.png';
			} else {
				$data['languages'][$key]['image'] = 'view/image/flags/' . $language['image'];
			}
		}
		
		
        $data['heading_title'] = $this->language->get('heading_title');

		$data['entry_status']                = $this->language->get('entry_status');
		$data['entry_customer_login']        = $this->language->get('entry_customer_login');
		$data['entry_customer_group']        = $this->language->get('entry_customer_group');
		$data['entry_limit']                 = $this->language->get('entry_limit');
		$data['entry_meta_description']      = $this->language->get('entry_meta_description');
		$data['entry_meta_title']            = $this->language->get('entry_meta_title');
		$data['entry_seo_url']               = $this->language->get('entry_seo_url');
		$data['entry_image_width']           = $this->language->get('entry_image_width');
		$data['entry_image_height']          = $this->language->get('entry_image_height');
		$data['entry_description_length']    = $this->language->get('entry_description_length');
		$data['entry_description_show']      = $this->language->get('entry_description_show');
		$data['entry_description_access']    = $this->language->get('entry_description_access');
		$data['entry_description_no_access'] = $this->language->get('entry_description_no_access');
		$data['entry_export']                = $this->language->get('entry_export');
		$data['entry_order']                 = $this->language->get('entry_order');
		$data['entry_pagination_show']       = $this->language->get('entry_pagination_show');
		$data['entry_pagination_page']       = $this->language->get('entry_pagination_page');
		$data['entry_export_price']          = $this->language->get('entry_export_price');

		$data['text_edit']              = $this->language->get('text_edit');
		$data['text_default']           = $this->language->get('text_default');
		$data['text_enabled']           = $this->language->get('text_enabled');
		$data['text_disabled']          = $this->language->get('text_disabled');
		$data['text_yes']               = $this->language->get('text_yes');
		$data['text_no']                = $this->language->get('text_no');
		$data['text_with_currency']     = $this->language->get('text_with_currency');

		$data['tab_general']            = $this->language->get('tab_general');
		$data['tab_export']             = $this->language->get('tab_export');

		$data['button_save']            = $this->language->get('button_save');
		$data['button_cancel']          = $this->language->get('button_cancel');
		$data['button_apply']           = $this->language->get('button_apply');
		
		$data['pagination_places']      = array(
			'bottom' => $this->language->get('text_bottom'),
			'top' =>    $this->language->get('text_top'),
			'both' =>   $this->language->get('text_both'),
		);

 		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

        $data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/dashbord', 'token=' . $this->session->data['token']),
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_module'),
			'href'      => $this->url->link($this->modulesPath, 'token=' . $this->session->data['token']),
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link($this->path, 'token=' . $this->session->data['token']),
   		);

		$data['action'] = $this->url->link($this->path, 'token=' . $this->session->data['token'], true);
		$data['apply']  = $this->url->link($this->path, 'token=' . $this->session->data['token'] . '&apply=1', true);
		$data['cancel'] = $this->url->link($this->modulesPath, 'token=' . $this->session->data['token'], true);

		$data['token'] = $this->session->data['token'];

		$price_list_default = array(
			'status'           => 0,
			'limit'            => $this->themeLimit,
			'customer_login'   => 0,
			'customer_group'   => array($this->config->get('config_customer_group_id')),
			'meta_description' => array(),
			'meta_title'       => array(),
			'image_width'      => $this->imageWidth,
			'image_height'     => $this->imageHeight,
			'descr_length'     => $this->descriptionLength,
		);
		$data['fields'] = $this->getFields();
        if (isset($this->request->post['price_list'])) {
      		$data['price_list'] = $this->request->post['price_list'];
    	} elseif ($this->config->has('price_list')){
			$data['price_list'] = $this->config->get('price_list');
		}

		foreach ($price_list_default as $key=>$value) {
			if (isset($data['price_list'][$key]) && $data['price_list'][$key]) continue;
			$data['price_list'][$key] = $value;
		}
		
		$data['seo_url'] = 'price_list';
		$sql = "SELECT * FROM " . DB_PREFIX . "url_alias WHERE query = 'product/price'";
		$results = $this->db->query($sql);
		$data['error_url_alias']   = '';
		$data['warning_url_alias'] = '';
		if ($results->num_rows > 1 ) {
			$data['error_url_alias'] = $this->language->get('error_few_url');
			$data['seo_url'] = '';
		} elseif ($results->num_rows) {
			$data['seo_url'] = $results->row['keyword'];
		} else {
			$data['warning_url_alias'] = $this->language->get('warning_url_alias');
		}

        $this->load->model('customer/customer_group');
        $data['customer_groups'] = $this->model_customer_customer_group->getCustomerGroups();

		$data['header']      = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer']      = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view($this->path . '.tpl', $data));
    }

    private function getFields() {
		$sql = "DESC " . DB_PREFIX . "product";
		$results = $this->db->query($sql);
		foreach ($results->rows as $result) {
			$fields['product'][]  = $result['Field'];
		}
		$sql = "DESC " . DB_PREFIX . "product_description";
		$results = $this->db->query($sql);
		foreach ($results->rows as $result) {
			$fields['description'][]  = $result['Field'];
		}
		return $fields;
	}
    private function validate() {
		if (!$this->user->hasPermission('modify', $this->path)) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (!$this->error) {
			return true;
		} else {
			return false;
		}
	}

	public function install() {
		$this->load->model('design/layout');
		$layouts = $this->model_design_layout->getLayouts();

		$layout_name = 'Price List';
		foreach($layouts as $layout){
			if($layout['name'] == $layout_name){
				$this->model_design_layout->deleteLayout($layout['layout_id']);
				break;
			}
		}
		$layout_data = array();
		$layout_data['name'] = $layout_name;

		$layout_data['layout_route'][0] = array(
			'store_id'=> '0',
			'route'	  => 'product/price'
		);

		$this->load->model('setting/store');
		$stores = $this->model_setting_store->getStores();
		foreach ($stores as $store) {
			$layout_data['layout_route'][] = array(
				'store_id'=> $store['store_id'],
				'route'	  => 'product/price'
			);
		}
		$this->model_design_layout->addLayout($layout_data);
	}

	public function uninstall() {
		$this->load->model('design/layout');
		$layouts = $this->model_design_layout->getLayouts();

		$layout_name = 'Price List';
		foreach($layouts as $layout){
			if($layout['name'] == $layout_name){
				$this->model_design_layout->deleteLayout($layout['layout_id']);
				break;
			}
		}
	}
}
