<?php
// Heading
$_['heading_title'] = '<span style="color:#CB4B16;text-decoration:none;"><b>CSV Price Pro import/export 4</b></span>';
$_['heading_title_normal'] = 'CSV Price Pro import/export 4';

$_['text_products'] = 'Товары';
$_['text_categories'] = 'Категории';
$_['text_manufacturers'] = 'Производители';
$_['text_crontab'] = 'Планировщик';
$_['text_customers'] = 'Клиенты';
$_['text_orders'] = 'Заказы';
$_['text_about'] = 'О модуле';