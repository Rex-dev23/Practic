<?php
// Heading
$_['heading_title'] = 'О модуле';
$_['heading_title_normal'] = 'CSV Price Pro import/export 4';

// Text
$_['text_module'] = 'Модули';
$_['text_license_key'] = 'Лицензия:';
$_['text_app_name'] = 'Модуль:';
$_['text_app_version'] = 'Версия:';
$_['text_home_page'] = 'Официальный сайт модуля:';
$_['text_empty_license'] = '<mark>Лицензионный ключ отсутствует</mark>';
$_['text_support_email'] = 'Техническая поддержка:';
$_['text_success_license_key'] = 'Лицензионный ключ успешно установлен!';
$_['text_show'] = 'показать';

$_['home_page'] = 'www.opencartlabs.ru';
$_['support_email'] = 'info@opencartlabs.ru';

// Butons
$_['button_save'] = 'Сохранить';

// Entry
$_['entry_license_key'] = 'Лицензия:';