<?php
// Heading
$_['heading_title'] = '<span class="f-heading-title">CSV Price Pro import/export 4</span>';
$_['heading_title_normal'] = 'CSV Price Pro import/export 4';

 // Text
$_['text_menu_product'] = 'Товары';
$_['text_menu_category'] = 'Категории';
$_['text_menu_manufacturer'] = 'Производители';
$_['text_menu_crontab'] = 'Планировщик';
$_['text_menu_customer'] = 'Клиенты';
$_['text_menu_order'] = 'Заказы';
$_['text_menu_about'] = 'О модуле';

$_['mod_demo'] = '0';
$_['mdemo_title'] = '
<p><a target="blank" href="http://store.opencartlabs.ru/obmen-dannymi/csv-price-pro-importexport-4-trial-key.html"><strong>Получить триальную лицензию на 7 дней для ознакомления с функционалом дополнения (модуля)</strong></a><br />
<a target="blank" href="http://www.opencartlabs.ru/csv-price-pro-importexport-3/csvprice3-download/"><strong>Условия продажи лицензий</strong></a><br />
<a target="blank" href="http://store.opencartlabs.ru/extensions-downloads.html"><strong>Скачать последнюю версию  CSV Price Pro import/export</strong></a><br />
<a target="blank" href="http://www.opencartlabs.ru/csv-price-pro-importexport-3/csvprice3-system-requirements/"><strong>Описание требований для работы дополнения (модуля)</strong></a><br />
<a target="blank" href="http://www.opencartlabs.ru/csv-price-pro-importexport-3/csvprice3-install/"><strong>Описание установки дополнения (модуля)</strong></a><br />
<a target="blank" href="http://demo.opencartlabs.ru/product_import_data.csv"><strong>Пример CSV-файла для импорта</strong></a>
</p>
';