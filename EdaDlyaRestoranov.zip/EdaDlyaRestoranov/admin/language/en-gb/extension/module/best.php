<?php
// Heading
$_['heading_title']       			= '<span style="color: #2E85BC; font-weight: bold; font-size: 14px;">Product of the day and Things to buy</span>';
$_['heading_title_title']           = 'Product of the day and Things to buy';
$_['setting_day']           		= 'Setting block Product of the day';
$_['setting_uspey']           		= 'Setting block Things to buy';
$_['ostalos']        	  			= 'Specify the initial amount<br />Product of the day to calculate the percentage of the balance sold<br /><span style="font-size: 9px;">(This number must not be less than the amount of goods in stock)</span>';
$_['style_best']          			= '<b>Settings Module styles</b>';
$_['text_color_best_day']      		= 'Color block Product of the day';
$_['text_header_color_best_day']    = 'The color of the text block header Product of the day';
$_['text_header_color_best_uspey']  = 'The color of the text block header Things to buy';

$_['text_color_name_product']  			= 'The color of the product name';
$_['text_font_size_name_product']  		= 'The size of the product name';
$_['text_color_price_product']  			= 'The color of the price of goods';
$_['text_font_size_price_product']  		= 'The size of the price of goods';
$_['text_color_priceold_product']  		= 'The color of the old price of the product';
$_['text_font_size_priceold_product']  	= 'The size of the old price of the product';
$_['text_color_pricenew_product']  		= 'Color promotional price of goods';
$_['text_font_size_pricenew_product']  	= 'The size of the promotional price of goods';
$_['text_gradient_ostatka']  			= 'Gradient color indicator balance from top to bottom';
$_['text_ot']  							= 'From';
$_['text_do']  							= 'Before';
$_['text_gradient_schetchik']  			= 'Gradient color counter end of the action from top to bottom';
$_['text_color_bg_button_cart']  		= 'Fill Color button Buy';
$_['text_color_text_button_cart']  		= 'Text Color button Buy';
$_['text_font_size_text_button_cart']  	= 'Text Size button Buy';
$_['text_color_compare']  				= 'The icon in the Compare';
$_['text_color_wishlist']  				= 'The icon in the Wishlist';

// Entry
$_['entry_product_day']   			= '<b>Specify the product of the day:<br /><span style="font-size: 11px;">(possible only 1 product)</span></b>';
$_['text_off_product_day']   		= 'Display Unit Product of the day';
$_['text_off_addit']   				= 'Additional Images';
$_['off_addit_pokaz']   			= 'Show:';
$_['text_schetchik']   				= 'Counter end stocks';
$_['text_rating_and_prodano']   	= 'Rating and light balance';
$_['text_responsive_setting']   	= '<b>Settings adaptability</b>';
$_['text_responsive']   			= 'Adaptability module<br><span style="font-size: 11px;">(for adaptive templates)</span>';
$_['text_kolvo_responsive_setting'] = 'The number of visible items in the block Things to buy<span style="font-size: 11px;">(at a resolution higher than 1200px and depending on the capacity of the module width)</span>';
$_['entry_product_uspey'] 			= '<b>Select items to display in the "Things to buy"</b> <span style="font-size: 11px; font-weight: normal;">(required)</span>';
$_['entry_limit']         			= 'Limit block "Things to buy":';
$_['entry_image']         			= 'Image (W x H):';
$_['entry_addit_image']         	= 'Additional. Image (W x H):';
$_['entry_layout']        			= 'Layout:';
$_['entry_position']      			= 'Location:';
$_['entry_status']        			= 'Status:';
$_['on']   							= 'On';
$_['off']   						= 'Off';

// Text
$_['text_module']      				= 'Modules';
$_['text_success']     				= 'Module "Product of the day and Things to buy" updated successfully!';
$_['text_edit']        				= 'Edit the module "Product of the day and Things to buy"';

// Entry
$_['entry_name']       				= 'The name of the module';
$_['entry_products']    			= 'Products';
$_['entry_product']    				= 'Product';
$_['entry_limit']      				= 'Limit';
$_['entry_width']      				= 'Width';
$_['entry_height']     				= 'Height';
$_['entry_status']     				= 'Status';

// Help
$_['help_product']     				= 'Autocomplete';

// Error
$_['error_permission'] 				= 'Warning: You are not allowed to control module!';
$_['error_name']       				= 'Module name should be between 3 and 64 characters!';
$_['error_width']      				= 'Specify the width!';
$_['error_height']     				= 'Enter the height!';

$_['protection']                    = '<span style="color: #FA0000;">Enter security code:</span>';
$_['help_protection']               = 'This secret code you need to ask the author, contact me by contacts:<span style="color: #FA0000; font-weight: bold;">aleksandr.rostov@mail.ru</span>, ICQ <span style="color: #FA0000; font-weight: bold;">406510166</span> или skype: <span style="color: #FA0000; font-weight: bold;">aleks.rostov85</span> previously stating<span style="text-decoration: underline;">точное время покупки шаблона</span>, а также <span style="text-decoration: underline;"> your domain name</span>, on which the pattern.<br />';
$_['help_cod_protection']           = 'Remember that the secret code linked to your domain to another domain, this module will not work';

?>
