<?php
require_once(DIR_LANGUAGE.'ru-ru/module/complete_seo.php');