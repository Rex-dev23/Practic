<?php
require_once(DIR_LANGUAGE.'ru-ru/feed/advanced_sitemap.php');