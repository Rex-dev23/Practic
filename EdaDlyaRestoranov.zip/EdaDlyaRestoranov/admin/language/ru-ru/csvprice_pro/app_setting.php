<?php
$_['error_permission'] = 'У Вас нет прав для управления модулем CSV Price Pro import/export!';
$_['error_directory_not_available'] = 'Рабочая директория модуля недоступна для записи или не существует';
$_['error_move_uploaded_file'] = 'Ошибка копирования файла!';
$_['error_uploaded_file'] = 'Файл не загружен!';
$_['error_copy_uploaded_file'] = 'Не удалось скопировать фaйл!';
$_['error_export_empty_rows'] = 'Нет данных для экспорта!';
$_['error_import_field_caption'] = 'Ошибка в заголвоках полей CSV файла!';
$_['error_unknown_error'] = 'Неизвестная ошибка...';
