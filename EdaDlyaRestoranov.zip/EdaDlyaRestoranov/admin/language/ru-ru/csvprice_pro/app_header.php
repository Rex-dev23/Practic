<?php
$_['csvprice_pro_heading_title'] = 'CSV Price Pro import/export OC2 &copy; <a target="blank" href="http://opencartlabs.ru/">opencartlabs.ru</a>';
$_['text_module_name'] = 'CSV Price Pro import/export OC2';
$_['text_menu_general'] = 'Основное';
$_['text_menu_product'] = 'Товары';
$_['text_menu_category'] = 'Категории';
$_['text_menu_manufacturer'] = 'Производители';
$_['text_menu_crontab'] = 'Планировщик';
$_['text_menu_customer'] = 'Клиенты';
$_['text_menu_order'] = 'Заказы';
$_['text_menu_about'] = 'О модуле';
$_['mod_demo'] = '0';
