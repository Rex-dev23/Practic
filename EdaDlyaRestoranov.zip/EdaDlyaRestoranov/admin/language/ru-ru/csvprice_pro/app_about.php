<?php
$_['heading_title'] = 'О модуле';
$_['heading_title_normal'] = 'CSV Price Pro import/export OC2';
$_['text_module'] = 'Модули';
$_['text_extension'] = 'Расширения';
$_['text_license_key'] = 'Лицензия:';
$_['text_app_name'] = 'Модуль:';
$_['text_app_version'] = 'Версия:';
$_['text_home_page'] = 'Официальный сайт модуля:';
$_['text_empty_license'] = '<mark>Лицензионный ключ отсутствует</mark>';
$_['text_support_email'] = 'Техническая поддержка:';
$_['text_success_license_key'] = 'Лицензионный ключ успешно установлен!';
$_['text_show'] = 'Показать';
$_['home_page'] = 'www.opencartlabs.ru';
$_['support_email'] = 'support@opencartlabs.ru';
$_['button_save'] = 'Сохранить';
$_['entry_license_key'] = 'Лицензия:';
$_['error_permission'] = 'Warning: You do not have permission to modify CSV Price Pro import/export!';
