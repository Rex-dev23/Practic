<?php
$_['module_name'] = 'CSV Price Pro import/export OC2';
$_['text_copy'] = '<a target="_blank" href="http://www.opencartlabs.ru/">www.opencartlabs.ru</a> &copy; 2011-%s Все права защищены.';
$_['text_version'] = 'Версия %s';
$_['text_show_help'] = 'Показать справку';
$_['text_confirm_delete'] = 'Удаление невозможно отменить! Вы уверены, что хотите это сделать?';
$_['text_show_help_note'] = 'Для получения справки нажмите на иконку <i class="f-icon-helper fa fa-info-circle fa-lg" aria-hidden="true" title=""></i>';
