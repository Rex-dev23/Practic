<?php
// Heading
$_['heading_title']    = 'Стена Категорий';

// Text
$_['text_module']      = 'Модули';
$_['text_success']     = 'Модуль обновлен';
$_['text_edit']        = 'Изменить модуль';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав на изменение модуля!';