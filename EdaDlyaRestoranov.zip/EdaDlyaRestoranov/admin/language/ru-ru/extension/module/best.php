<?php
// Heading
$_['heading_title']       			= '<span style="color: #2E85BC; font-weight: bold; font-size: 14px;">Товар дня и Успей купить</span>';
$_['heading_title_title']           = 'Товар дня и Успей купить';
$_['setting_day']           		= 'Настройка блока Товар дня';
$_['setting_uspey']           		= 'Настройка блока Успей купить';
$_['ostalos']        	  			= 'Укажите  первоначальное количество<br />Товара дня для расчета процента проданного от остатка<br /><span style="font-size: 9px;">(это число не должно быть меньше количества товара в наличии)</span>';

$_['style_best']          			= '<b>Настройки стилей модуля</b>';
$_['text_color_best_day']      		= 'Цвет блока Товар дня';
$_['text_header_color_best_day']    = 'Цвет текста заголовка блока Товар дня';
$_['text_header_color_best_uspey']  = 'Цвет текста заголовка блока Успей купить';

$_['text_color_name_product']  			= 'Цвет названия товара';
$_['text_font_size_name_product']  		= 'Размер названия товара';
$_['text_color_price_product']  			= 'Цвет цены товара';
$_['text_font_size_price_product']  		= 'Размер цены товара';
$_['text_color_priceold_product']  		= 'Цвет старой цены товара';
$_['text_font_size_priceold_product']  	= 'Размер старой цены товара';
$_['text_color_pricenew_product']  		= 'Цвет акционной цены товара';
$_['text_font_size_pricenew_product']  	= 'Размер акционной цены товара';
$_['text_gradient_ostatka']  			= 'Градиент цвета индикатора остатка сверху вниз';
$_['text_ot']  							= 'От';
$_['text_do']  							= 'до';
$_['text_gradient_schetchik']  			= 'Градиент цвета счетчика конца акции сверху вниз';
$_['text_color_bg_button_cart']  		= 'Цвет заливки кнопки Купить';
$_['text_color_text_button_cart']  		= 'Цвет текста кнопки Купить';
$_['text_font_size_text_button_cart']  	= 'Размер текста кнопки Купить';
$_['text_color_compare']  				= 'Цвет значка в Сравнение';
$_['text_color_wishlist']  				= 'Цвет значка в Закладки';

// Entry
$_['entry_product_day']   			= '<b>Укажите Товар дня:<br /><span style="font-size: 11px;">(возможен только 1 товар)</span></b>';
$_['text_off_product_day']   		= 'Отображение блока Товар дня';
$_['text_off_addit']   				= 'Дополнительные изображения товара';
$_['off_addit_pokaz']   			= 'Показывать:';
$_['text_schetchik']   				= 'Счетчик конца акции';
$_['text_rating_and_prodano']   	= 'Рейтинг и индикатор остатка';
$_['text_responsive_setting']   	= '<b>Настройки адаптивности</b>';
$_['text_responsive']   			= 'Адаптивность модуля<br /><span style="font-size: 11px; color: #FA0000;">(Выберите <span style="font-weight: bold;">Откл</span> в случае, если вы устанавливаете модуль в Левую или Правую колонку сайта)</span>';
$_['text_kolvo_responsive_setting'] = 'Количество видимых товаров в блоке Успей купить<span style="font-size: 11px;"> (при разрешениях экрана выше 1200px и в зависимости от вместимости модуля по ширине)</span>';
$_['entry_product_uspey'] 			= '<b>Укажите товары для отображения в блоке "Успей купить"</b> <span style="font-size: 11px; font-weight: normal;">(обязательно для заполнения)</span>';
$_['entry_limit']         			= 'Лимит блока "Успей купить":';
$_['entry_image']         			= 'Изображение (Ш x В):';
$_['entry_addit_image']         	= 'Дополнит. изображения (Ш x В):';
$_['entry_layout']        			= 'Макет:';
$_['entry_position']      			= 'Расположение:';
$_['entry_status']        			= 'Статус:';
$_['on']   							= 'Вкл';
$_['off']   						= 'Откл';

// Text
$_['text_module']      				= 'Модули';
$_['text_success']     				= 'Модуль "Товар дня и Успей купить" успешно обновлен!';
$_['text_edit']        				= 'Редактирование модуля "Товар дня и Успей купить"';

// Entry
$_['entry_name']       				= 'Название модуля';
$_['entry_products']    			= 'Товары';
$_['entry_product']    				= 'Товар';
$_['entry_limit']      				= 'Лимит';
$_['entry_width']      				= 'Ширина';
$_['entry_height']     				= 'Высота';
$_['entry_status']     				= 'Статус';

// Help
$_['help_product']     				= 'Автозаполнение';

// Error
$_['error_permission'] 				= 'Внимание: У Вас недостаточно прав для управления модулем!';
$_['error_name']       				= 'Название модуля должно быть от 3 до 64 символов!';
$_['error_width']      				= 'Укажите ширину!';
$_['error_height']     				= 'Укажите высоту!';

$_['protection']                    = '<span style="color: #FA0000;">Введите секретный код:</span>';
$_['help_protection']               = 'Данный секретный код вам нужно запросить у автора, связавшись со мной по контактам: <span style="color: #FA0000; font-weight: bold;">aleksandr.rostov@mail.ru</span>, ICQ <span style="color: #FA0000; font-weight: bold;">406510166</span> или skype: <span style="color: #FA0000; font-weight: bold;">aleks.rostov85</span>, предварительно указав <span style="text-decoration: underline;">точное время покупки шаблона</span>, а также <span style="text-decoration: underline;">название своего домена</span>, на котором установлен шаблон.<br />';
$_['help_cod_protection']           = 'Помните, что секретный код привязан к вашему рабочему домену, с другим доменом данный модуль работать не будет';
$_['protection_no_base']            = 'Вы используете локальный домен. Если модуль автоматически не откроется, нажмите кнопку <span style="color: #FA0000;">ПРИМЕНИТЬ</span>';

?>
