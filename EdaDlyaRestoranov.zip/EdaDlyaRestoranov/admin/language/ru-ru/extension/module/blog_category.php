<?php
// Heading
$_['heading_title']    = 'Блог: Категории';

// Text
$_['text_module']      = 'Модули';
$_['text_success']     = 'Успешно: Вы изменили модуль вывода категорий блога';
$_['text_edit']        = 'Редактирование модуля';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Ошибка: У вас нет доступа для изменения модуля';