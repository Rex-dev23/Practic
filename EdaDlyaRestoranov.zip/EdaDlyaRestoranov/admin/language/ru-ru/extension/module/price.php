<?php
// Heading
$_['heading_title']             = 'Прайс лист';

// Text
$_['text_edit']                = 'Редактирование настроек расширения Прайс лист';
$_['text_module']              = 'Модули';
$_['text_success']             = 'Success: Вы изменили настройки расширения (модуля) Slasoft Прайслист';
$_['text_bottom']                 = 'Внизу прайса';
$_['text_top']                    = 'Вверху прайса';
$_['text_both']                   = 'Внизу и вверху';
$_['text_with_currency']          = 'Цена с валютой';

$_['tab_general']                 = 'Основные настройки';
$_['tab_export']                  = 'Настройуи для экспорта';


//Entry
$_['entry_status']             = 'Статус';
$_['entry_customer_login']     = 'Доступность только зарегистрированным покупателям';
$_['entry_customer_group']     = 'Доступность только покупателям из указанных групп';
$_['entry_limit']              = 'Минимальное количество товаров';
$_['entry_meta_description']   = 'Meta description';
$_['entry_meta_title']         = 'Meta title';
$_['entry_seo_url']            = 'Seo ЧПУ';
$_['entry_image_width']        = 'Ширина изображения';
$_['entry_image_height']       = 'Высота изображения';
$_['entry_description_length'] = 'Длина описания товара';
$_['entry_description_show']      = 'Показывать описание товара';
$_['entry_description_no_access'] = 'Text Description if user have not access';
$_['entry_description_access']    = 'Описание страницы';
$_['entry_export']                = 'Включить в файл экспотра';
$_['entry_order']                 = 'Порядок полей';
$_['entry_pagination_show']       = 'Show description with pagination';
$_['entry_pagination_page']       = 'Место для пагинации';
$_['entry_export_price']          = 'Настройки поля цена';


// Error
$_['error_permission']         = 'Warning: Вы не можете изменять SlaSoft Price List extension!';
$_['error_url_alias']          = 'Warning: Несколько строк соответсвий в url_alias!';
$_['warning_url_alias']        = 'Warning: ЧПУ отстуствует!';