<?php
$_['heading_title'] = 'CSV Price Pro import/export OC2 &copy;';
$_['heading_title_normal'] = 'CSV Price Pro import/export OC2';
$_['text_general'] = 'Основное';
$_['text_products'] = 'Товары';
$_['text_categories'] = 'Категории';
$_['text_manufacturers'] = 'Производители';
$_['text_crontab'] = 'Планировщик';
$_['text_customers'] = 'Клиенты';
$_['text_orders'] = 'Заказы';
$_['text_about'] = 'О модуле';
