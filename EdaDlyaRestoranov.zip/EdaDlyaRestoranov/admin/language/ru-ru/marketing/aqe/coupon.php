<?php

// Text
$_['text_success_delete']           = 'Success: %s coupon(s) deleted!';

// Actions
$_['action_product']                = 'Products';
$_['action_products']               = 'Products';
$_['action_category']               = 'Categories';
$_['action_categories']             = 'Categories';
$_['action_prod']                   = 'P';
$_['action_cat']                    = 'C';
