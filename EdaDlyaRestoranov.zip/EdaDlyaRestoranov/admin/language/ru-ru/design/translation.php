<?php
// Heading
$_['heading_title']    = 'Перевод';

// Text
$_['text_edit']        = 'Редактирование';
$_['text_list']        = 'Перевод';
$_['text_translation'] = 'Выбрать';
$_['text_translation'] = 'Выбрать';

// Column
$_['column_flag']      = 'Флаг';
$_['column_country']   = 'Страна';
$_['column_progress']  = 'Процесс перевода';
$_['column_action']    = 'Действие';

// button
$_['button_install']   = 'Установить';
$_['button_uninstall'] = 'Удалить';
$_['button_refresh']   = 'Обновить';

// Error
$_['error_permission'] = 'У Вас нет прав для изменения настроек!';


