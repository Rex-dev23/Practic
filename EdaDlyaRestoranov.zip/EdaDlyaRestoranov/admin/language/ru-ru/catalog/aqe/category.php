<?php

// Text
$_['text_success_copy']             = 'Success: %s category(s) copied!';
$_['text_success_delete']           = 'Success: %s category(s) deleted!';
$_['text_rebuilding']               = 'Rebuilding ...';

// Actions
$_['action_name']                   = 'Category Name';

// Errors
$_['error_name']                    = 'Category Name must be between 1 and 255 characters!';
