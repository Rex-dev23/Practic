<?php

// Text
$_['text_success_delete']           = 'Success: %s review(s) deleted!';
